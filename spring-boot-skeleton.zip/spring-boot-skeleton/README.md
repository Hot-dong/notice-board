# 스프링 유틸리티 프로젝트

spring boot jpa, mybatis, querydsl 기본 프로젝트

spring boot version 2.5.3

기본 환경 세팅 목록
1. jsp
2. jstl
3. lombok
4. modelmapper
5. mybatis
6. jpa
7. querydsl
