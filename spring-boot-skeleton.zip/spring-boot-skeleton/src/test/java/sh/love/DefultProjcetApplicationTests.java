package sh.love;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DefultProjcetApplicationTests {

    @Test
    void contextLoads() {
    }

}
