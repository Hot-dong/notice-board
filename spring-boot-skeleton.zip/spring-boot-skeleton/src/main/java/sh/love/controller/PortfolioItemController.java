package sh.love.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/portfolioItem")
public class PortfolioItemController {

    @RequestMapping(value = "")
    public String main(Model model){
        return "/user/portfolioItem/portfolioItem";
    }

}
