package sh.love.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/blog-home")
public class BlogHomeController {

    @RequestMapping(value = "")
    public String main(Model model){
        return "/user/blogHome/blogHome";
    }

}
