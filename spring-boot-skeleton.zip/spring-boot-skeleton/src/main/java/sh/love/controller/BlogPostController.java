package sh.love.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/blog-post")
public class BlogPostController {

    @RequestMapping(value = "")
    public String main(Model model){
        return "/user/blogPost/blogPost";
    }

}
