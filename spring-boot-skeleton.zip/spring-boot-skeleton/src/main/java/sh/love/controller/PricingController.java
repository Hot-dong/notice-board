package sh.love.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/pricing")
public class PricingController {

    @RequestMapping(value = "")
    public String main(Model model){
        return "/user/pricing/pricing";
    }

}
