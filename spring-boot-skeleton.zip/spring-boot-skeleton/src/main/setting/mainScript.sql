create table main(
     sn int auto_increment primary key ,
     cn varchar(100)
);

insert into main(cn) values('내용1');
insert into main(cn) values('내용2');
